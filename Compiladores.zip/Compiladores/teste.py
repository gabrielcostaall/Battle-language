from battle_lexer import BattleLexer
from battle_parser import BattleParser
from battle_interpreter import BattleInterpreter

lexer = BattleLexer()
parser = BattleParser()
interpreter = BattleInterpreter()

def run(command):
    ast = parser.parse(lexer.tokenize(command))
    result = interpreter.execute(ast)
    print(result)

run ("CONVOCAR Guerreiro")
run ('aprender (nome_ataque: "tiro", dano: 30, mana: 50)')
run ("ATACAR tiro na Barriga")
run ("DEFENDER Cura")